import pickle
from flask import Flask, request, render_template
from flask import Response
from flask_cors import CORS,cross_origin
import pandas as pd
import numpy as np
from sklearn.neighbors import KNeighborsClassifier

application = Flask(__name__)
CORS(application)
application.config['DEBUG'] = True

with open("modelForPrediction.sav", 'rb') as f:
    model = pickle.load(f)

nba = pd.read_csv("nba_2013.csv")  # Reading the Data

x_columns = nba[['age', 'g', 'gs', 'mp', 'fg', 'fga', 'fg.', 'x3p', 'x3pa', 'x3p.', 'x2p', 'x2pa', 'x2p.', 'efg.', 'ft', 'fta',
     'ft.', 'orb', 'drb', 'trb', 'ast', 'stl', 'blk', 'tov', 'pf']]

@application.route('/',methods=['GET'])  # route to display the home page
@cross_origin()
def homePage():
    return render_template("index.html")



@application.route("/predict", methods =['POST'])
def predictRoute():

    try:

        float_features = [float(x) for x in request.form.values()]
        final_features = [np.array(float_features)]
        prediction = model.predict(final_features)
        print('prediction is', prediction)
        return render_template('results.html', prediction=(100 * prediction))

    except Exception as e:
        print('The Exception message is: ', e)
        return 'something is wrong'



if __name__ == "__main__":
    host = '0.0.0.0'
    port = 5000
    application.run(debug=True)
    httpd = simple_server.make_server(host,port,app)
    #print("serving on %s %d % (host ,port))
    #httpd.serve_forever()


